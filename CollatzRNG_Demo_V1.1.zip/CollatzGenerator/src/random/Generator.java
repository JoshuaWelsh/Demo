package random;

import java.time.LocalTime;
import java.util.function.Supplier;

public class Generator implements Supplier {
	private static int maxCallOffset = Integer.MAX_VALUE-2999997;
	private static long initialized = LocalTime.now().getNano();
	private static long callOffset = 0;
	private long instantiated, lastCall;
	
	public Generator() {
		this.instantiated = LocalTime.now().getNano();
	}
	
	long getSeed() {
		callOffset = (callOffset+1)%maxCallOffset;
		this.lastCall = LocalTime.now().getNano();
		return this.getInitialized() + this.getInstantiated() + this.getLastCall() + callOffset;
	}

	//Convert Binary String to Int and Return
	private long seed = 1;
	private int value = 0;
	@Override
	public Object get() {
		//Guarantees different seeds
		if (this.lastCall == LocalTime.now().getNano()) {
			stall();
			this.lastCall = LocalTime.now().getNano();
		}
		
		int bit = 1_073_741_824; //Value of Leftmost Bit in 32 bit Signed Big Endian Number Systems
		while (bit!=0) {
			if (bitIsOne()) {
				value ^= bit; //Bitwise add for efficiency
			}
			bit >>>= 1; //Bitwise division by two for a power of two
		}
		
		//Allow Negative Values
		if (bitIsOne()) {
			value = -value;
		}
		
		return value;
	}
	
	private int lastSeed = 1;
	//Generate Bits for Binary String
	private boolean bitIsOne() {
		//Check for Invalid Domain
		while (seed == 1.0 || seed == -1.0) {seed = getSeed();}
		
		//Iterated Collatz Conjecture
		if (seed % 2 == 0) {
			seed = seed/2;
			if (seed % 2 == 0) {
				seed = seed/2;
				return true;
			}

			else {
				seed = seed*3 + 1;
				return false;
			}
		}
		else {
			seed = seed*3 + 1;
			return false;
		}
	}
	
	//Package-Private Methods for Unit Tests
	static long getInitialized() {
		return initialized;
	}
	long getInstantiated() {
		return this.instantiated;
	}
	long getLastCall() {
		return this.lastCall;
	}
	
	//Creates a Small Delay
	private void stall() {
		long time = LocalTime.now().getNano();
		while (time == LocalTime.now().getNano()) {} //Continues Polling until Nanosecond Time-stamp Changes
	}
}
