package random;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GeneratorTest {
	@Test
	void test() throws InterruptedException {
		assert seedWorks() : "Seed Generation Error";
		assert generatorWorks() : "Generated Value Error";
	}

	private boolean generatorWorks() {
		int firstGenerated, secondGenerated;
		
		Generator first = new Generator();
		stall();
		Generator second = new Generator();
		
		int duplicates = 0;
		double firstMean = 0;
		double secondMean = 0;
		for (int i = 1; i<10000; i++) {
			//Get and Compare Random Numbers from Stream
			firstGenerated = (int) first.get();
			secondGenerated = (int) second.get();
			if (firstGenerated == secondGenerated) {
				duplicates+=1;
			}
			
			//Tabulate Weighted Mean
			firstMean += (firstGenerated-firstMean)/i;
			secondMean += (secondGenerated-secondMean)/i;
			stall();
		}
		
		//Check for Excessive (Improbable) Duplication
		if (duplicates > 5) {
			System.out.println("GENERATED VALUE: Too many duplicates.");
			System.out.println("Duplicates: "+duplicates);
			return false;
		}
		
		//Check for Atypical (Improbable) Means
		if (firstMean>1.15E9 || firstMean<0.95E9) {
			System.out.println("GENERATED VALUE: Atypical Mean");
			System.out.println("Mean: "+firstMean);
			return false;
		}
		return true;
	}
	
	private boolean seedWorks() {
		//Assuming Working Until a Test is Failed
		boolean isWorking = true;
		
		//Initialize Generators at Different Times
		Generator first = new Generator();
		stall();
		Generator second = new Generator();

		//Test for System Dependence (Static Instantiation Time)
		if (first.getInitialized() != second.getInitialized()){
			System.out.println("SEED: Seed static component is not static.");
			isWorking = false;
		}

		//Test for Instance Dependence (Initialization Time)
		if (first.getInstantiated() == second.getInstantiated()) { //Not guaranteed to be unique
			stall();
			Generator third = new Generator();
			if (first.getInstantiated() == second.getInstantiated()) { //Probability of consecutive duplicates when properly working is 1 in 10^7, so not likely
				System.out.println("SEED: Seed is not instance dependent.");
				isWorking = false;
			}
		}

		//Test for Time Dependence (Time of Last Call)
		first.getSeed();
		stall();
		second.getSeed();
		if (first.getLastCall() == second.getLastCall()) { //Not guaranteed to be unique
			stall();
			second.getSeed();
			if (first.getLastCall() == second.getLastCall()) { //Probability of consecutive duplicates when properly working is 1 in 10^7, so not likely
				System.out.println("SEED: Seed is not time dependent.");
				isWorking = false;
			}
		}
		
		return isWorking;
	}
	
	//Creates a Small Delay
	private void stall() {
		long time = LocalTime.now().getNano();
		while (time == LocalTime.now().getNano()) {} //Continues Polling until Nanosecond Time-stamp Changes
	}
}
