package primestream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

public class PrimeGenerator implements Supplier{
	//Static - Static Steam Prevents Unnecessary Recalculations During Multiple-Instantiation
	private static CopyOnWriteArrayList<Integer> primes = new CopyOnWriteArrayList<Integer>(Arrays.asList(2,3,5,7,11,13,17,19,23,29));
	private static int primeCount = primes.size();
	private static AtomicBoolean writing = new AtomicBoolean(false);
	
	//Instance
	private Iterator<Integer> iterator;
	
	//Constructor
	public PrimeGenerator(){this.iterator = primes.iterator();}

	//Tracks current stream position
	private int index = 0;
	
	//Stream Methods
	public Object get(){
		//Generates numbers and prevents multiple threads from simultaneously generating the same numbers
		if (!this.iterator.hasNext() && !writing.get()) {
			writing.set(true);
			generatePrimes();
		}
		writing.set(false);
		
		//Updates iterator to reflect changes
		this.iterator = primes.listIterator(index++);
		
		//Returns Value
		return this.iterator.next();
	}
	
	//Prime Generator and Variables
	private static int NEEDED = 5; //How many primes to generate at a time
	private static int lastEnd = 2;
	private static int primesGenerated, candidate;
	private static boolean isValidPrime;
	private static synchronized boolean generatePrimes() { //Prime Generator - Generates new primes each time it is run, allows for lazy prime generation for stream
		primesGenerated = 0;
		
		//Initialize
		candidate = primes.get(primeCount-1); //Starts checking at next odd number above the highest last-known prime, after increment in loop

		//Work
		while (primesGenerated<NEEDED) {
			isValidPrime = true;
			
			//Proceed
			candidate += 2; //Increments candidate, skipping even numbers
			
			//Test
			for (int prime : primes) {
				if (prime>lastEnd && prime*prime>candidate) { //Stops checking candidate if factors become implausibly big
					lastEnd = primes.indexOf(prime);
					break; 
				}
				else if(candidate%prime == 0){ //Stops checking candidate if candidate has any factors
					isValidPrime = false;
					break;
				}
			}
			
			//Store
			if (isValidPrime) {
				primes.add(candidate);
				primeCount++;
				primesGenerated++;	
			}
		}
		
		return true;
	}
}
