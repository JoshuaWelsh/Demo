package primestream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.stream;

import java.time.LocalTime;

import org.junit.jupiter.api.Test;

class PrimeGeneratorTest {
	private static int[] vettedPrimes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71 , 73, 79, 83, 89, 97}; //From: http://primes.utm.edu/
	private PrimeGenerator p1, p2;
	private int[] p1Results, p2Results;
	
	@Test
	void test() {
		System.out.println("Starting Test");
		
		//Initialize Storage
		p1Results = new int[25];
		p2Results = new int[25];
		
		//Initialize Generators
		p1 = new PrimeGenerator();
		p2 = new PrimeGenerator();
		
		//Generate Two Arrays
		System.out.println("Generating Values");
		for (int i = 0; i<25; i++) {
			p1Results[i] = (int) p1.get();
			p2Results[i] = (int) p2.get();
			System.out.println(i+": "+p1Results[i]+", "+p2Results[i]);
		}
		System.out.println("Performing Assertions");
		
		//Check consistency
		assertArrayEquals(p1Results,p2Results);
		System.out.println("Results are consistent and streams are independent.");
		
		//Check accuracy
		assertArrayEquals(p1Results,vettedPrimes);
		System.out.println("Results are accurate.");
		System.out.println("---All Tests Passed---");
	}
}
